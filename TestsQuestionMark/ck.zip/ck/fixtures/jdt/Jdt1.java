package jdt;

public class Jdt1 {
	
	public void m1() {
	}

	public void m2(int a, double b) {}

	public void m3(int a, A a, double c);

	public void m4(int a, int[] b, String[] c, A... d);
}
