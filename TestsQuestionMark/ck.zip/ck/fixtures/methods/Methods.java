package methods;

public class Methods {
	
	private int a() {}
	private String b() {}
	public double c() {}
	private static String d() {}
	public static int e() {}

	int f() {}
	protected double g() {}

	public synchronized int h() {}

	public final void display(){
		System.out.println("display");
	}
	
}