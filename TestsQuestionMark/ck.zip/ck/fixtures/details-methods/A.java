package methods2;

public class A {

	public void m1() {
		
	}
}