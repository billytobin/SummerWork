package methods2;

public class A1 {
	
	private int a() {
		int a = 0;
		int b = 1;

		int c = 2, d = 3;
		String c = "mau";

	}

	public void b() {

	}

	public void c(int a, int b, A a) {
		int a = 1;
	}

	public void d() {
		int a = 10;
		if(a < 10) return 1;
		if(b < 10) return 2;
		return 3;
	}

	public void e() {
		int a = 10;
		return;
	}
	
}