package cbo;

public class MethodParams {

	public void m(A a, B b) {
		a.doSomething();
	}
}
