package cbo;

class Coupling8 {
    public A sampleMethod() {
        return SampleClassWithStaticMethod.sampleMethod();
    }
}