package VariableDeclaration;

public class VariableDeclaration {
    private int a = 0, b=20;

    private int c=10;

    boolean d;

    protected int e=b+10;

    private int f
            = 10;

    private int g      = 10;

    private String xx;
}