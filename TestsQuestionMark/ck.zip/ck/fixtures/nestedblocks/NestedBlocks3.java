package nestedblocks;

class NestedBlocks3 {

	public void m1() {
		int a = 0;
		int b = 0;
		int c = 0;
		int d = 0;

		for(int i = 0; i < 10; i++)
			for(int j = 0; j < 10; j++) {
				while(true) {
					do {
						do d++; while (c < 0);
					} while (d < 0);

					for(;;) {
						d++;
					}
				}
			}

	}

	
}