package nestedblocks;

class NestedBlocks8 {


	public int x = 0;
	public Integer y = new Integer(10);
	
}