package math;

class Math {
	
	public void m1() {
		int a = 10 + 1;
		int b = 10 - 1;
	}

	public void m2() {
		int c = 10 / 2;
		int d = 10 * 2;
		int e = 10 % 2;
	}

	public void m3() {
		
	}
}