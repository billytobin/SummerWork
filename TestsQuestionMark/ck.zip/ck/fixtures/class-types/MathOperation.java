package classtypes;

interface MathOperation {
	int operation(int a, int b);
}