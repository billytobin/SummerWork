package rfc;

public class GO3 extends GO2 {
	
	public void x() {
		x();
		super.magic();
	}
}